CREATE DATABASE online_retail_db;

USE online_retail_db;

CREATE TABLE online_retail (
    InvoiceNo VARCHAR(20),
    StockCode VARCHAR(20),
    Description VARCHAR(255),
    Quantity INT,
    InvoiceDate DATETIME,
    UnitPrice DECIMAL(10,2),
    CustomerID INT,
    Country VARCHAR(100)
);

SELECT * FROM online_retail LIMIT 10;

SELECT COUNT(*) AS total_records
FROM online_retail;

SELECT COUNT(DISTINCT CustomerID) AS Total_Customers
FROM online_retail;

SELECT
    SUM(Quantity * UnitPrice) AS Total_Revenue
FROM online_retail;

SELECT COUNT(DISTINCT InvoiceNo) AS Total_Orders
FROM online_retail
WHERE InvoiceNo NOT LIKE 'C%';

SELECT
    Country,
    COUNT(DISTINCT CustomerID) AS Total_Customers
FROM online_retail
GROUP BY Country
ORDER BY Total_Customers DESC;

SELECT *
FROM online_retail
WHERE Country = 'United Kingdom';

SELECT *
FROM online_retail
WHERE Quantity * UnitPrice > 100;

SELECT
    Country,
    ROUND(SUM(Quantity * UnitPrice), 2) AS Revenue
FROM online_retail
WHERE Quantity > 0
AND UnitPrice > 0
AND InvoiceNo NOT LIKE 'C%'
GROUP BY Country
ORDER BY Revenue DESC;

SELECT
    CustomerID,
    SUM(Quantity * UnitPrice) AS Total_Spending
FROM online_retail
WHERE CustomerID IS NOT NULL
AND Quantity > 0
AND UnitPrice > 0
AND InvoiceNo NOT LIKE 'C%'
GROUP BY CustomerID
HAVING SUM(Quantity * UnitPrice) > 1000;

CREATE TABLE customers AS
SELECT DISTINCT
    CustomerID,
    Country
FROM online_retail
WHERE CustomerID IS NOT NULL;

SELECT
    c.CustomerID,
    c.Country,
    o.InvoiceNo,
    o.Quantity,
    o.UnitPrice
FROM customers c
INNER JOIN online_retail o
ON c.CustomerID = o.CustomerID;

SELECT
    c.CustomerID,
    c.Country,
    o.InvoiceNo
FROM customers c
LEFT JOIN online_retail o
ON c.CustomerID = o.CustomerID;

SELECT
    CustomerID,
    SUM(Quantity * UnitPrice) AS Total_Spending,
    CASE
        WHEN SUM(Quantity * UnitPrice) >= 5000
            THEN 'High Value'
        WHEN SUM(Quantity * UnitPrice) >= 1000
            THEN 'Medium Value'
        ELSE 'Low Value'
    END AS Customer_Category
FROM online_retail
WHERE CustomerID IS NOT NULL
AND Quantity > 0
AND UnitPrice > 0
AND InvoiceNo NOT LIKE 'C%'
GROUP BY CustomerID;

SELECT
    CustomerID,

    DATEDIFF(
        (SELECT MAX(InvoiceDate) + INTERVAL 1 DAY
         FROM online_retail),
        MAX(InvoiceDate)
    ) AS Recency,

    COUNT(DISTINCT InvoiceNo) AS Frequency,

    SUM(Quantity * UnitPrice) AS Monetary

FROM online_retail

WHERE CustomerID IS NOT NULL
AND Quantity > 0
AND UnitPrice > 0
AND InvoiceNo NOT LIKE 'C%'

GROUP BY CustomerID;

SELECT COUNT(*) AS Total_Records
FROM online_retail;

SELECT COUNT(*) AS Total_Customers
FROM customers;

SELECT *
FROM online_retail
LIMIT 10;